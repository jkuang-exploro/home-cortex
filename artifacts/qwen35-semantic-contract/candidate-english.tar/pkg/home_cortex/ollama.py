import json
from collections.abc import AsyncIterator, Mapping, Sequence
from typing import Any, cast

from ollama import AsyncClient, ChatResponse

from .text import latest_user_message

PLANNER_KEEP_ALIVE = "24h"
PLANNER_NUM_PREDICT = 384

_PLANNER_INSTRUCTIONS = """You are Home Cortex's semantic interpreter. Translate the latest user message into one semantic request. Return compact JSON only; never calculate or phrase the answer. Household identities, the authenticated speaker's identity, and the assistant's identity are facts. Only ordinary conversation uses requires_fact=false, request=null.

Output grammar:
{"requires_fact":true,"request":{"operation":OPERATION,"subject":REFERENCE,"property":PROPERTY_OR_NULL,"property_source":"entity" OR "relationship"}}
REFERENCE = {"kind":REFERENCE_KIND,"value":LITERAL_NAME_OR_NULL,"entity_type":TYPE,"path":[{"concept":CONCEPT}, ...]}. An empty path means the base reference itself. Optional request fields: filters (collection conditions), other (second reference for a comparison), mode (days or seconds), from_unit and to_unit (conversion only).

Reference meaning:
- self is the authenticated speaker, never a guessed named household member. assistant is this assistant. Their entity_type is person and value is null. current_household is the configured home, entity_type=address, value=null.
- named_entity is only a literal stored name or appellation copied from the user's text; do not infer kinship for a personal name. Never originate entity IDs.
- Each reference_concept is a complete declared meaning, including its filters. Choose the most specific matching concept from its aliases. Do not replace son with child, wife with spouse, or father with parent. Do not reproduce a concept's expansion in the output: select its concept name and the ontology expands it.
- Compose nested relatives by appending concepts. Adjectives constrain the SAME person and do not add another hop. Extra step filters only narrow the selected concept. A speaker's family relatives start at self, not all household members.
- Household list/count/extrema use current_household followed by member. Household adults/minors additionally use their declared predicate in request.filters. Unqualified children means household minors; explicitly possessive children means the speaker's child relation. Home-address questions use self followed by residence, then full_address. Respect relation_signatures for source/target types.

Operation meaning:
- A person's identity or name (including self or assistant) is resolve_reference; leave property=null. A specific component of a name can use select(given_name/family_name). select with property=null means a requested LIST, not an individual identity. count means the size of a collection.
- For a projected property use select. For age use completed_years(birth_date).
- argmin returns the person whose ordered property is smallest; argmax returns the person whose property is largest. The ontology defines the meanings of property minima and maxima. With birth_date: OLDER/OLDEST/EARLIER BORN = argmin; YOUNGER/YOUNGEST/LATER BORN = argmax. Do not mistake a larger age for a larger birth_date. Use argmin/argmax for these person queries, not min/max or earliest/latest.
- A two-person comparison requires the ordered property AND both complete references in subject and other. If the speaker participates, subject=self and other is the second person. A collection extremum has no other.
- Birthday date = select(birth_date). Next birthday = annual_occurrence(birth_date). Countdown from today to a birthday = annual_occurrence(birth_date), mode=days; never duration/date_difference from the original birth date.
- Elapsed time since a start date = duration with mode=days (seconds only if requested). A relationship duration uses one traversed relationship reference in subject, not two person operands.

Property ownership:
Use property_ownership to choose property_source explicitly. entity means the final entity's property. relationship means the FINAL traversed edge's property, requires a nonempty path, and has no other operand. A spouse's birth_date belongs to entity. Marriage start_date belongs to the spouse relationship; duration consumes that same relationship start_date. With no property use property_source=entity. Never silently change an invalid owner.

Filters have separate productions. Field comparisons use {property,value} and optional operator/source/value_from/value_property; source=entity targets the person/place, source=relation targets the edge. value_from=anchor compares with the base reference. Declared predicates use ONLY {predicate:NAME} in request.filters. Their definition_only metadata explains meaning; never emit it as extra predicates. completed_years is an operation, not a predicate. Do not drop unsupported constraints, invent vocabulary, or guess identities. Do not solve the factual question.
"""


def _semantic_planner_examples() -> list[dict[str, str]]:
    """Small grammar illustrations; no evaluation wording or household answers."""
    def reference(kind: str, *concepts: str) -> dict[str, Any]:
        return {"kind": kind, "value": None,
                "entity_type": "address" if kind == "current_household" else "person",
                **({"path": [{"concept": name} for name in concepts]} if concepts else {})}

    examples = (
        ("Please identify the speaker.", "resolve_reference", reference("self"), None, "entity", {}),
        ("Please identify this assistant.", "resolve_reference", reference("assistant"), None, "entity", {}),
        ("Which person is my mother's husband?", "resolve_reference", reference("self", "mother", "husband"), None, "entity", {}),
        ("How many days since I moved into my residence?", "duration", reference("self", "residence"), "start_date", "relationship", {"mode": "days"}),
        ("Between me and my father, who was born earlier?", "argmin", reference("self"), "birth_date", "entity", {"other": reference("self", "father")}),
        ("Which household member was born last?", "argmax", reference("current_household", "member"), "birth_date", "entity", {}),
        ("How many adult residents are in this household?", "count", reference("current_household", "member"), None, "entity", {"filters": [{"predicate": "adult"}]}),
        ("How many days until my daughter's next birthday?", "annual_occurrence", reference("self", "daughter"), "birth_date", "entity", {"mode": "days"}),
    )
    messages: list[dict[str, str]] = []
    for utterance, operation, subject, prop, owner, extra in examples:
        request = {"operation": operation, "subject": subject, "property": prop,
                   "property_source": owner, **extra}
        messages.extend((
            {"role": "user", "content": utterance},
            {"role": "assistant", "content": json.dumps(
                {"requires_fact": True, "request": request},
                ensure_ascii=False, separators=(",", ":"),
            )},
        ))
    return messages


class OllamaService:
    """Make individual Ollama chat calls for the Cortex agent."""

    def __init__(
        self,
        base_url: str,
        model: str,
        client: AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._owns_client = client is None
        self.client = client or AsyncClient(host=self.base_url)
        self.last_planner_runtime: dict[str, Any] = {}
        self._cached_planner_system: str | None = None
        self._cached_planner_capabilities_id: int | None = None

    async def chat(
        self,
        messages: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one ordinary chat request without exposing tools."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            stream=False,
            think=False,
        )

    async def chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one request that lets the model choose a read-only Cortex tool."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=False,
            think=False,
        )

    def _planner_system_prompt(self, capabilities: Mapping[str, Any]) -> str:
        marker = id(capabilities)
        if (
            self._cached_planner_system is not None
            and self._cached_planner_capabilities_id == marker
        ):
            return self._cached_planner_system
        prompt = (
            _PLANNER_INSTRUCTIONS
            + "\nCapabilities:\n"
            + json.dumps(capabilities, ensure_ascii=False, separators=(",", ":"))
        )
        self._cached_planner_system = prompt
        self._cached_planner_capabilities_id = marker
        return prompt

    async def plan_semantic_fact(
        self,
        messages: Sequence[Mapping[str, Any]],
        capabilities: Mapping[str, Any],
        output_schema: Mapping[str, Any],
        *,
        household_now: str,
    ) -> Mapping[str, Any]:
        """Interpret an open-ended request without exposing physical storage."""
        forwarded: list[dict[str, Any]] = [
            {"role": "user", "content": latest_user_message(messages)}
        ]
        validation_feedback = "\n".join(
            str(message.get("content", "")) for message in messages
            if message.get("role") == "system"
            and "strict structural validation" in str(message.get("content", ""))
        )
        response = await self.client.chat(
            model=self.model,
            messages=[
                {"role": "system", "content": (
                    self._planner_system_prompt(capabilities)
                    + f"\nHousehold now: {household_now}"
                    + ("\n" + validation_feedback if validation_feedback else "")
                )},
                *_semantic_planner_examples(),
                *forwarded,
            ],
            stream=False,
            think=False,
            keep_alive=PLANNER_KEEP_ALIVE,
            format=dict(output_schema),
            options={"temperature": 0, "num_predict": PLANNER_NUM_PREDICT},
        )
        self.last_planner_runtime = _ollama_runtime_metrics(response)
        parsed = json.loads(response.message.content or "")
        if not isinstance(parsed, Mapping):
            raise ValueError("Semantic fact planner returned a non-object")
        return parsed

    async def stream_chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> AsyncIterator[ChatResponse]:
        """Stream one response while allowing read-only Cortex tool calls."""
        response = await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=True,
            think=False,
        )
        stream = cast(AsyncIterator[ChatResponse], response)
        try:
            async for chunk in stream:
                yield chunk
        finally:
            close = getattr(stream, "aclose", None)
            if close is not None:
                await close()

    async def close(self) -> None:
        if self._owns_client:
            await self.client.close()


def _ns_to_ms(value: int | float | None) -> float:
    return 0.0 if not value else float(value) / 1_000_000


def _ollama_runtime_metrics(response: ChatResponse) -> dict[str, Any]:
    return {
        "prompt_eval_count": int(getattr(response, "prompt_eval_count", 0) or 0),
        "prompt_eval_duration_ms": _ns_to_ms(
            getattr(response, "prompt_eval_duration", None)
        ),
        "eval_count": int(getattr(response, "eval_count", 0) or 0),
        "eval_duration_ms": _ns_to_ms(getattr(response, "eval_duration", None)),
        "load_duration_ms": _ns_to_ms(getattr(response, "load_duration", None)),
    }
