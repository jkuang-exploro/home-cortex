import json
from collections.abc import AsyncIterator, Mapping, Sequence
from typing import Any, cast

from ollama import AsyncClient, ChatResponse

from .text import latest_user_message

PLANNER_KEEP_ALIVE = "24h"
PLANNER_NUM_PREDICT = 384

_PLANNER_INSTRUCTIONS = """You are Home Cortex's semantic interpreter. Interpret the latest request as one composable semantic request. Return only JSON, never an answer. Identity, names, relationships and household facts require requires_fact=true. Ordinary conversation uses requires_fact=false, request=null.

Build references before choosing the operation:
- self is the authenticated speaker; for speaker-relative phrases choose kind=self. assistant is this assistant. current_household is the configured home (entity_type=address). named_entity holds only a literal stored name or appellation from the user's text. Never infer a person's identity, ID or kinship from a name. Context resolves identities later.
- A reference_concept is a complete path INCLUDING EVERY FILTER. Filters are part of its meaning, even when the current data might identify a unique person without them. Expand each concept and append its entire path to compose references. Each step's filters apply to that step's target, never to a later relative. Do this independently for subject and other.
- Canonical scope: a home-address request traverses self->residence with full_address.
- Household collections traverse current_household->member. A speaker's descendants traverse self->child. Unqualified children/minors (有几个孩子) means current_household->member plus predicate=minor; explicit possessive children (我有几个孩子) means self->child. Do not add an implicit possessive.

Choose the outer operation from operations; other vocabulary is not an operation:
- Identity: resolve_reference and leave property=null. Name properties may use select. List: select with property=null. Count: count with property=null. A property value: select. Age: completed_years(birth_date).
- An extremum uses argmin or argmax AND its ordered property. When comparing two people, put one complete reference in subject and the second in other. When one operand is the speaker, use subject=self and other for the second person. A collection extremum has other=null. Earlier birth_date means older (argmin); later birth_date means younger (argmax). Preserve both operands regardless of wording order.
- A birthday date uses select(birth_date); next birthday uses annual_occurrence(birth_date); countdown to that birthday adds mode=days. A duration since a date uses duration and a required mode days or seconds. Unqualified duration uses days.

Explicitly choose property_source for every request using property_ownership:
- entity selects a property of the final person/place. relationship selects a property of the FINAL TRAVERSED EDGE and requires a path. The relationship determines which relationship properties exist. Never substitute one owner for another.
- Thus a spouse's birth_date belongs to entity; the spouse relationship's start_date belongs to relationship. Property aliases describe meaning, not ownership. Ownership is always recorded in property_source, not source. With property=null use property_source=entity.

Filters have two distinct forms:
- A field comparison is {property, value} with optional operator, source, value_from and value_property. source=entity filters the step's target; source=relation filters the edge. value_from=anchor compares with the base reference entity.
- A declared collection predicate is ONLY {predicate: <declared name>}, in request.filters. Use the predicate's declared meaning, including definition_only (a definition, never extra output filters). Do not reimplement its definition with extra predicates. Operations such as completed_years are never predicate names.
Request filters select from the final collection before the outer operation. They cannot replace filters that define intermediate relatives. Copy all concept filters even in identity/name requests. Only advertised vocabulary is supported. Do not repair unsupported meaning by dropping constraints or guessing. Do not solve the factual question.
"""


def _semantic_planner_examples() -> list[dict[str, str]]:
    # Illustrate reusable composition with wording excluded from evaluation.
    examples: tuple[tuple[str, dict[str, Any]], ...] = (
        ("我母亲的丈夫是哪位？", {
            "operation": "resolve_reference",
            "subject": {"kind": "self", "path": [
                {"relation": "parent", "filters": [{"property": "gender", "value": "female"}]},
                {"relation": "spouse", "filters": [{"property": "gender", "value": "male"}]},
            ]},
            "property": None, "property_source": "entity",
        }),
        ("我的居住关系始于哪天？", {
            "operation": "select",
            "subject": {"kind": "self", "path": [{"relation": "residence"}]},
            "property": "start_date", "property_source": "relationship",
        }),
        ("母亲与父亲两人中哪位更年轻？", {
            "operation": "argmax",
            "subject": {"kind": "self", "path": [
                {"relation": "parent", "filters": [{"property": "gender", "value": "female"}]},
            ]},
            "other": {"kind": "self", "path": [
                {"relation": "parent", "filters": [{"property": "gender", "value": "male"}]},
            ]},
            "property": "birth_date", "property_source": "entity",
        }),
        ("列出本户的未成年成员。", {
            "operation": "select",
            "subject": {"kind": "current_household", "entity_type": "address", "path": [{"relation": "member"}]},
            "filters": [{"predicate": "minor"}],
            "property_source": "entity",
        }),
        ("林青下次过生日离今天还有几天？", {
            "operation": "annual_occurrence",
            "subject": {"kind": "named_entity", "value": "林青", "entity_type": "person"},
            "property": "birth_date", "property_source": "entity", "mode": "days",
        }),
    )
    from .semantic_facts import SemanticFactRequest

    messages: list[dict[str, str]] = []
    for utterance, request in examples:
        for key in ("subject", "other"):
            reference = request.get(key)
            if reference is not None:
                reference.setdefault("entity_type", "person")
        parsed = SemanticFactRequest.model_validate(request)
        request = parsed.model_dump(mode="json", exclude_defaults=True)
        request = {key: request.get(key, getattr(parsed, key)) for key in
                   ("operation", "subject", "property", "property_source")} | {
            key: value for key, value in request.items()
            if key not in {"operation", "subject", "property", "property_source"}
        }
        for key in ("subject", "other"):
            if key in request:
                reference = request[key]
                request[key] = {"kind": reference["kind"], "value": reference.get("value"),
                                "entity_type": reference["entity_type"],
                                **({"path": reference["path"]} if "path" in reference else {})}
        messages.extend((
            {"role": "user", "content": utterance},
            {"role": "assistant", "content": json.dumps(
                {"requires_fact": True, "request": request},
                ensure_ascii=False, separators=(",", ":"),
            )},
        ))
    return messages


class OllamaService:
    """Make individual Ollama chat calls for the Cortex agent."""

    def __init__(
        self,
        base_url: str,
        model: str,
        client: AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._owns_client = client is None
        self.client = client or AsyncClient(host=self.base_url)
        self.last_planner_runtime: dict[str, Any] = {}
        self._cached_planner_system: str | None = None
        self._cached_planner_capabilities_id: int | None = None

    async def chat(
        self,
        messages: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one ordinary chat request without exposing tools."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            stream=False,
            think=False,
        )

    async def chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one request that lets the model choose a read-only Cortex tool."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=False,
            think=False,
        )

    def _planner_system_prompt(self, capabilities: Mapping[str, Any]) -> str:
        marker = id(capabilities)
        if (
            self._cached_planner_system is not None
            and self._cached_planner_capabilities_id == marker
        ):
            return self._cached_planner_system
        prompt = (
            _PLANNER_INSTRUCTIONS
            + "\nCapabilities:\n"
            + json.dumps(capabilities, ensure_ascii=False, separators=(",", ":"))
        )
        self._cached_planner_system = prompt
        self._cached_planner_capabilities_id = marker
        return prompt

    async def plan_semantic_fact(
        self,
        messages: Sequence[Mapping[str, Any]],
        capabilities: Mapping[str, Any],
        output_schema: Mapping[str, Any],
        *,
        household_now: str,
    ) -> Mapping[str, Any]:
        """Interpret an open-ended request without exposing physical storage."""
        forwarded: list[dict[str, Any]] = [
            {"role": "user", "content": latest_user_message(messages)}
        ]
        validation_feedback = "\n".join(
            str(message.get("content", "")) for message in messages
            if message.get("role") == "system"
            and "strict structural validation" in str(message.get("content", ""))
        )
        response = await self.client.chat(
            model=self.model,
            messages=[
                {"role": "system", "content": (
                    self._planner_system_prompt(capabilities)
                    + f"\nHousehold now: {household_now}"
                    + ("\n" + validation_feedback if validation_feedback else "")
                )},
                *_semantic_planner_examples(),
                *forwarded,
            ],
            stream=False,
            think=False,
            keep_alive=PLANNER_KEEP_ALIVE,
            format=dict(output_schema),
            options={"temperature": 0, "num_predict": PLANNER_NUM_PREDICT},
        )
        self.last_planner_runtime = _ollama_runtime_metrics(response)
        parsed = json.loads(response.message.content or "")
        if not isinstance(parsed, Mapping):
            raise ValueError("Semantic fact planner returned a non-object")
        return parsed

    async def stream_chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> AsyncIterator[ChatResponse]:
        """Stream one response while allowing read-only Cortex tool calls."""
        response = await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=True,
            think=False,
        )
        stream = cast(AsyncIterator[ChatResponse], response)
        try:
            async for chunk in stream:
                yield chunk
        finally:
            close = getattr(stream, "aclose", None)
            if close is not None:
                await close()

    async def close(self) -> None:
        if self._owns_client:
            await self.client.close()


def _ns_to_ms(value: int | float | None) -> float:
    return 0.0 if not value else float(value) / 1_000_000


def _ollama_runtime_metrics(response: ChatResponse) -> dict[str, Any]:
    return {
        "prompt_eval_count": int(getattr(response, "prompt_eval_count", 0) or 0),
        "prompt_eval_duration_ms": _ns_to_ms(
            getattr(response, "prompt_eval_duration", None)
        ),
        "eval_count": int(getattr(response, "eval_count", 0) or 0),
        "eval_duration_ms": _ns_to_ms(getattr(response, "eval_duration", None)),
        "load_duration_ms": _ns_to_ms(getattr(response, "load_duration", None)),
    }
