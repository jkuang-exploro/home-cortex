import json
from collections.abc import AsyncIterator, Mapping, Sequence
from typing import Any, cast

from ollama import AsyncClient, ChatResponse

from .text import latest_user_message

PLANNER_KEEP_ALIVE = "24h"
PLANNER_NUM_PREDICT = 384

_PLANNER_INSTRUCTIONS = """你是语义解释器。把用户问题编译成一个 JSON 语义请求，不计算答案。事实、身份、姓名问题 requires_fact=true；闲聊 false 且 request=null。Do not solve the factual question.

引用语法：
self 是当前说话人（choose kind=self），assistant 是助手，current_household 是当前家庭（entity_type=address）。人物的 entity_type=person。named_entity.value 只能是用户原文的姓名或称呼（literal stored name or appellation），不得猜测 ID 或姓名对应的亲属关系。非 named_entity 的 value=null。
path 是概念的有序组合，每步 {"concept":"声明的概念"}，可附加 filters 缩小范围。亲属用 reference_concepts 的完整概念，不要把 wife/son/father 简化成 spouse/child/parent。概念由本体自动展开成完整路径及性别等条件，不允许覆盖。多层亲属按顺序组合概念：配偶的母亲是 [{"concept":"spouse"},{"concept":"mother"}]；妻子的母亲必须用 wife 而非 spouse。
家庭集合是 current_household->member；没有“我的”等所属限定的“孩子”指家庭 minor，不是说话人的 child。个人住址是 self->residence，再取 full_address。

外层操作：
问某人是谁、叫什么，resolve_reference，leave property=null。明确问姓/名的组成部分用 select(family_name/given_name)。列出集合用 select 且 property=null；计数用 count 且 property=null。
选择属性用 select；年龄用 completed_years(birth_date)。出生日期/生日日期用 select(birth_date)；下一次生日用 annual_occurrence(birth_date)；问从今天到生日还有/相隔多少天仍然用 annual_occurrence，mode=days，绝不是从出生当天算 date_difference/duration。
从一个起始日期持续到现在用 duration(property)，mode=days（秒数才 seconds）。
最年长/年龄大/较老 = argmin(birth_date)，最年轻/年龄小 = argmax(birth_date)。比较两个人必须有两个完整引用 subject 和 other，且必须指定 property=birth_date。包含说话人时 subject=self，另一人在 other；比较家庭集合时 subject=current_household->member，other 省略。不要交换出生早晚和年龄大小。

属性所有者必须明确：property_ownership.entity 是最终实体的属性，property_ownership.relationship 是最终关系边的属性。用 property_source 选择所有者。配偶的 birth_date 是 entity；关系的 start_date/end_date 是 relationship，包括婚姻开始日期。无 property 时 source=entity。不能用实体属性替换关系属性。

过滤语法：
字段条件 {"property":"属性","value":值} 可有 operator 和 source（entity 或 relation）；value_from=anchor 引用起点实体。
集合谓词只能是 {"predicate":"collection_predicates 中的名称"}，放在 request.filters。definition_only 只是定义，不要展开为额外条件；completed_years 等操作不是谓词。保留所有用户限定；不能删除不支持的条件来凑出可执行的请求。只用已声明的操作、属性、关系、概念、谓词。
"""

def _semantic_planner_examples() -> list[dict[str, str]]:
    # Illustrate reusable composition with wording excluded from evaluation.
    examples: tuple[tuple[str, dict[str, Any]], ...] = (
        ("我母亲的丈夫是哪位？", {
            "operation": "resolve_reference",
            "subject": {"kind": "self", "path": [
                {"concept": "mother"},
                {"concept": "husband"},
            ]},
            "property": None, "property_source": "entity",
        }),
        ("我的居住关系始于哪天？", {
            "operation": "select",
            "subject": {"kind": "self", "path": [{"concept": "residence"}]},
            "property": "start_date", "property_source": "relationship",
        }),
        ("我与父亲两人中哪位更年轻？", {
            "operation": "argmax",
            "subject": {"kind": "self"},
            "other": {"kind": "self", "path": [
                {"concept": "father"},
            ]},
            "property": "birth_date", "property_source": "entity",
        }),
        ("列出本户的未成年成员。", {
            "operation": "select",
            "subject": {"kind": "current_household", "entity_type": "address", "path": [{"concept": "member"}]},
            "filters": [{"predicate": "minor"}],
            "property_source": "entity",
        }),
        ("林青下次过生日离今天还有几天？", {
            "operation": "annual_occurrence",
            "subject": {"kind": "named_entity", "value": "林青", "entity_type": "person"},
            "property": "birth_date", "property_source": "entity", "mode": "days",
        }),
    )
    messages: list[dict[str, str]] = []
    for utterance, request in examples:
        request.setdefault("property", None)
        for key in ("subject", "other"):
            if key in request:
                reference = request[key]
                request[key] = {"kind": reference["kind"], "value": reference.get("value"),
                                "entity_type": reference.get("entity_type", "person"),
                                **({"path": reference["path"]} if "path" in reference else {})}
        request = {key: request[key] for key in ("operation", "subject", "property", "property_source")} | {
            key: value for key, value in request.items()
            if key not in {"operation", "subject", "property", "property_source"}
        }
        messages.extend((
            {"role": "user", "content": utterance},
            {"role": "assistant", "content": json.dumps(
                {"requires_fact": True, "request": request},
                ensure_ascii=False, separators=(",", ":"),
            )},
        ))
    return messages


class OllamaService:
    """Make individual Ollama chat calls for the Cortex agent."""

    def __init__(
        self,
        base_url: str,
        model: str,
        client: AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._owns_client = client is None
        self.client = client or AsyncClient(host=self.base_url)
        self.last_planner_runtime: dict[str, Any] = {}
        self._cached_planner_system: str | None = None
        self._cached_planner_capabilities_id: int | None = None

    async def chat(
        self,
        messages: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one ordinary chat request without exposing tools."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            stream=False,
            think=False,
        )

    async def chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one request that lets the model choose a read-only Cortex tool."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=False,
            think=False,
        )

    def _planner_system_prompt(self, capabilities: Mapping[str, Any]) -> str:
        marker = id(capabilities)
        if (
            self._cached_planner_system is not None
            and self._cached_planner_capabilities_id == marker
        ):
            return self._cached_planner_system
        prompt = (
            _PLANNER_INSTRUCTIONS
            + "\nCapabilities:\n"
            + json.dumps(capabilities, ensure_ascii=False, separators=(",", ":"))
        )
        self._cached_planner_system = prompt
        self._cached_planner_capabilities_id = marker
        return prompt

    async def plan_semantic_fact(
        self,
        messages: Sequence[Mapping[str, Any]],
        capabilities: Mapping[str, Any],
        output_schema: Mapping[str, Any],
        *,
        household_now: str,
    ) -> Mapping[str, Any]:
        """Interpret an open-ended request without exposing physical storage."""
        forwarded: list[dict[str, Any]] = [
            {"role": "user", "content": latest_user_message(messages)}
        ]
        validation_feedback = "\n".join(
            str(message.get("content", "")) for message in messages
            if message.get("role") == "system"
            and "strict structural validation" in str(message.get("content", ""))
        )
        response = await self.client.chat(
            model=self.model,
            messages=[
                {"role": "system", "content": (
                    self._planner_system_prompt(capabilities)
                    + f"\nHousehold now: {household_now}"
                    + ("\n" + validation_feedback if validation_feedback else "")
                )},
                *_semantic_planner_examples(),
                *forwarded,
            ],
            stream=False,
            think=False,
            keep_alive=PLANNER_KEEP_ALIVE,
            format=dict(output_schema),
            options={"temperature": 0, "num_predict": PLANNER_NUM_PREDICT},
        )
        self.last_planner_runtime = _ollama_runtime_metrics(response)
        parsed = json.loads(response.message.content or "")
        if not isinstance(parsed, Mapping):
            raise ValueError("Semantic fact planner returned a non-object")
        return parsed

    async def stream_chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> AsyncIterator[ChatResponse]:
        """Stream one response while allowing read-only Cortex tool calls."""
        response = await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=True,
            think=False,
        )
        stream = cast(AsyncIterator[ChatResponse], response)
        try:
            async for chunk in stream:
                yield chunk
        finally:
            close = getattr(stream, "aclose", None)
            if close is not None:
                await close()

    async def close(self) -> None:
        if self._owns_client:
            await self.client.close()


def _ns_to_ms(value: int | float | None) -> float:
    return 0.0 if not value else float(value) / 1_000_000


def _ollama_runtime_metrics(response: ChatResponse) -> dict[str, Any]:
    return {
        "prompt_eval_count": int(getattr(response, "prompt_eval_count", 0) or 0),
        "prompt_eval_duration_ms": _ns_to_ms(
            getattr(response, "prompt_eval_duration", None)
        ),
        "eval_count": int(getattr(response, "eval_count", 0) or 0),
        "eval_duration_ms": _ns_to_ms(getattr(response, "eval_duration", None)),
        "load_duration_ms": _ns_to_ms(getattr(response, "load_duration", None)),
    }
