import json
from collections.abc import AsyncIterator, Mapping, Sequence
from typing import Any, cast

from ollama import AsyncClient, ChatResponse

from .text import latest_user_message

PLANNER_KEEP_ALIVE = "24h"
PLANNER_NUM_PREDICT = 384

_PLANNER_INSTRUCTIONS = 'You are Home Cortex\'s semantic interpreter. Map the latest user request to exactly one supported semantic request. Household member identity, the authenticated speaker\'s identity, and this assistant\'s identity are facts in this domain. Only ordinary conversation emits requires_fact=false and request=null. Return only the strict structured output; never calculate or phrase the answer.\n\nIdentity and name questions are always facts here: resolve the speaker as resolve_reference(self), the assistant as resolve_reference(assistant), and relatives as resolve_reference(self followed by declared concepts). In every such case requires_fact=true and leave property=null. Questions for the assistant\'s name are also resolve_reference(assistant), never ordinary conversation.\n\nReferences: self is always the authenticated speaker, assistant is this assistant, current_household is the configured home, and named_entity contains only a literal stored name or appellation from the user. Never emit entity_id or put pronouns/relationship phrases in a named_entity. For speaker-relative phrases choose kind=self. Each path step selects {"concept":"name"} from reference_concepts. The ontology expands its complete path and filters. Compose nested relatives by appending concept steps. Adjectives constrain the same target; do not add a hop for gender. Use the most specific declared concept: son is not child, wife is not spouse, father is not parent.\n\nCanonical disambiguation: household member list/count uses current_household->member with no filters. Unqualified household adults/minors use exactly one adult/minor request filter. Unqualified adult/minor predicate filters contain only predicate=adult/minor; do not attach an age value or property. Unqualified children means household minors; possessive children means self followed by child. Chinese 最年长/最老/最早出生 = argmin(birth_date); 最年幼/最年轻/年纪最小/最晚出生 = argmax(birth_date). 老婆/妻子 means self->spouse[gender=female]. A literal personal name must be named_entity using exactly that text; do not infer a family relationship for a name. Address questions use self->residence and property=full_address.\n\nUse only advertised semantic relations, properties, predicates and operations—never storage fields, SQL, file names, or code. Use resolve_reference for identity and leave property=null; use select for a property or list, count for size, completed_years for age, and argmin/argmax for extrema. Earlier birth_date is older: oldest=argmin, youngest=argmax. Collection predicates adult/minor belong in request.filters after traversing current_household->member; a speaker\'s children instead traverse self->child.\n\nA birthday date is select(birth_date); its next occurrence is annual_occurrence(birth_date); a birthday countdown adds mode=days. Phrasing such as \'from today until the birthday\' is still the next annual occurrence, not date_difference from the original birth date. A person\'s home address is self->residence then full_address. Metadata owned by the final edge uses property_source=relationship. Marriage start is select(self->spouse, start_date, relationship); marriage duration uses duration on that same relationship property with a mode. A spouse\'s birth_date is an entity property and must keep property_source=entity; only relationship metadata such as start_date or end_date uses relationship. Do not solve the factual question.\nRequest shape: {"operation":OP,"subject":REFERENCE,"property":PROPERTY_OR_NULL,"property_source":"entity" OR "relationship"}. REFERENCE is {"kind":KIND,"value":null OR LITERAL_NAME,"entity_type":TYPE,"path":[{"concept":CONCEPT},...]}. Contextual values are null. Optional request.other is the second reference for a two-person comparison; prefer subject=self when the speaker participates. Relationship property requests have no other and require a traversed path. The declared relation_signatures define the valid source and target types. Extra concept-step filters are conjunctive with the full ontology definition. Return compact JSON.'

def _semantic_planner_examples() -> list[dict[str, str]]:
    """Small grammar illustrations; no evaluation wording or household answers."""
    def reference(kind: str, *concepts: str) -> dict[str, Any]:
        return {"kind": kind, "value": None,
                "entity_type": "address" if kind == "current_household" else "person",
                **({"path": [{"concept": name} for name in concepts]} if concepts else {})}

    examples = (
        ("请统计本户常住成员数量。", "count", reference("current_household", "member"), None, "entity", {}),
        ("在本户成员中找出出生日期最靠前的人。", "argmin", reference("current_household", "member"), "birth_date", "entity", {}),
        ("在本户成员中找出出生日期最靠后的人。", "argmax", reference("current_household", "member"), "birth_date", "entity", {}),
        ("本户达到成年标准的成员合计多少？", "count", reference("current_household", "member"), None, "entity", {"filters": [{"predicate": "adult"}]}),
        ("请确定我的丈夫是哪一位。", "resolve_reference", reference("self", "husband"), None, "entity", {}),
        ("查一下我的居住地街道地址。", "select", reference("self", "residence"), "full_address", "entity", {}),
        ("女儿下个生日距今有多少天？", "annual_occurrence", reference("self", "daughter"), "birth_date", "entity", {"mode": "days"}),
        ("我与母亲相比，出生较早的是谁？", "argmin", reference("self"), "birth_date", "entity", {"other": reference("self", "mother")}),
    )
    messages: list[dict[str, str]] = []
    for utterance, operation, subject, prop, owner, extra in examples:
        request = {"operation": operation, "subject": subject, "property": prop,
                   "property_source": owner, **extra}
        messages.extend((
            {"role": "user", "content": utterance},
            {"role": "assistant", "content": json.dumps(
                {"requires_fact": True, "request": request},
                ensure_ascii=False, separators=(",", ":"),
            )},
        ))
    return messages


class OllamaService:
    """Make individual Ollama chat calls for the Cortex agent."""

    def __init__(
        self,
        base_url: str,
        model: str,
        client: AsyncClient | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._owns_client = client is None
        self.client = client or AsyncClient(host=self.base_url)
        self.last_planner_runtime: dict[str, Any] = {}
        self._cached_planner_system: str | None = None
        self._cached_planner_capabilities_id: int | None = None

    async def chat(
        self,
        messages: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one ordinary chat request without exposing tools."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            stream=False,
            think=False,
        )

    async def chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> ChatResponse:
        """Send one request that lets the model choose a read-only Cortex tool."""
        return await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=False,
            think=False,
        )

    def _planner_system_prompt(self, capabilities: Mapping[str, Any]) -> str:
        marker = id(capabilities)
        if (
            self._cached_planner_system is not None
            and self._cached_planner_capabilities_id == marker
        ):
            return self._cached_planner_system
        prompt = (
            _PLANNER_INSTRUCTIONS
            + "\nCapabilities:\n"
            + json.dumps(capabilities, ensure_ascii=False, separators=(",", ":"))
        )
        self._cached_planner_system = prompt
        self._cached_planner_capabilities_id = marker
        return prompt

    async def plan_semantic_fact(
        self,
        messages: Sequence[Mapping[str, Any]],
        capabilities: Mapping[str, Any],
        output_schema: Mapping[str, Any],
        *,
        household_now: str,
    ) -> Mapping[str, Any]:
        """Interpret an open-ended request without exposing physical storage."""
        forwarded: list[dict[str, Any]] = [
            {"role": "user", "content": latest_user_message(messages)}
        ]
        validation_feedback = "\n".join(
            str(message.get("content", "")) for message in messages
            if message.get("role") == "system"
            and "strict structural validation" in str(message.get("content", ""))
        )
        response = await self.client.chat(
            model=self.model,
            messages=[
                {"role": "system", "content": (
                    self._planner_system_prompt(capabilities)
                    + f"\nHousehold now: {household_now}"
                    + ("\n" + validation_feedback if validation_feedback else "")
                )},
                *_semantic_planner_examples(),
                *forwarded,
            ],
            stream=False,
            think=False,
            keep_alive=PLANNER_KEEP_ALIVE,
            format=dict(output_schema),
            options={"temperature": 0, "num_predict": PLANNER_NUM_PREDICT},
        )
        self.last_planner_runtime = _ollama_runtime_metrics(response)
        parsed = json.loads(response.message.content or "")
        if not isinstance(parsed, Mapping):
            raise ValueError("Semantic fact planner returned a non-object")
        return parsed

    async def stream_chat_with_tools(
        self,
        messages: Sequence[Mapping[str, Any]],
        tools: Sequence[Mapping[str, Any]],
    ) -> AsyncIterator[ChatResponse]:
        """Stream one response while allowing read-only Cortex tool calls."""
        response = await self.client.chat(
            model=self.model,
            messages=messages,
            tools=tools,
            stream=True,
            think=False,
        )
        stream = cast(AsyncIterator[ChatResponse], response)
        try:
            async for chunk in stream:
                yield chunk
        finally:
            close = getattr(stream, "aclose", None)
            if close is not None:
                await close()

    async def close(self) -> None:
        if self._owns_client:
            await self.client.close()


def _ns_to_ms(value: int | float | None) -> float:
    return 0.0 if not value else float(value) / 1_000_000


def _ollama_runtime_metrics(response: ChatResponse) -> dict[str, Any]:
    return {
        "prompt_eval_count": int(getattr(response, "prompt_eval_count", 0) or 0),
        "prompt_eval_duration_ms": _ns_to_ms(
            getattr(response, "prompt_eval_duration", None)
        ),
        "eval_count": int(getattr(response, "eval_count", 0) or 0),
        "eval_duration_ms": _ns_to_ms(getattr(response, "eval_duration", None)),
        "load_duration_ms": _ns_to_ms(getattr(response, "load_duration", None)),
    }
